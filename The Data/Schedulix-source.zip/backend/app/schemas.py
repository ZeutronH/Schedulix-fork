from datetime import time, date, datetime
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import Optional


class LoginRequest(BaseModel):
    username: str
    password: str


class AdminCreate(BaseModel):
    username: str
    email: EmailStr
    password: str = Field(min_length=12)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class DepartmentCreate(BaseModel):
    name: str
    code: str
    description: Optional[str] = None


class ProgrammeCreate(BaseModel):
    department_id: str
    name: str
    code: str
    duration_years: int = Field(ge=1, le=10)


class AcademicYearCreate(BaseModel):
    name: str
    start_date: date
    end_date: date


class SectionCreate(BaseModel):
    semester_id: str
    programme_id: str
    name: str
    student_count: int = Field(ge=0)


class SubjectCreate(BaseModel):
    department_id: str
    code: str
    name: str
    session_type: str
    default_duration: int = Field(gt=0, le=480)


class FacultyCreate(BaseModel):
    faculty_id: str
    department_id: str
    full_name: str
    email: EmailStr
    phone: Optional[str] = None
    whatsapp_number: Optional[str] = None
    designation: Optional[str] = None


class StudentCreate(BaseModel):
    student_id: str
    full_name: str
    email: EmailStr
    admission_year: int
    phone: Optional[str] = None
    whatsapp_number: Optional[str] = None


class AssignmentCreate(BaseModel):
    faculty_id: str
    subject_id: str
    section_id: str
    sessions_per_week: int = Field(ge=1, le=20)
    duration_minutes: int = Field(gt=0, le=480)
    priority: int = Field(ge=1, le=10)
    required_capacity: int = Field(ge=1)
    required_room_type: str


class RoomCreate(BaseModel):
    floor_id: str
    name: str
    room_type: str
    capacity: int = Field(gt=0)
    equipment: list[str] = []


class CampusNodeCreate(BaseModel):
    name: str
    node_type: str
    building_id: Optional[str] = None
    floor_id: Optional[str] = None
    room_id: Optional[str] = None


class CampusEdgeCreate(BaseModel):
    source_id: str
    target_id: str
    distance: float = Field(ge=0)
    connection_type: str
    bidirectional: bool = True
    accessible: bool = True


class ScheduleRequest(BaseModel):
    mode: str = "HYBRID"
    priority_weight: float = Field(default=0.65, ge=0, le=1)
    sjf_weight: float = Field(default=0.35, ge=0, le=1)
    weekdays: list[int] = [0, 1, 2, 3, 4, 5]
    day_start: time = time(8, 0)
    day_end: time = time(18, 0)
    time_limit_seconds: int = Field(default=30, ge=1, le=300)


class ApprovalRequest(BaseModel):
    comments: Optional[str] = None


class AvailabilityCreate(BaseModel):
    resource_type: str
    resource_id: str
    start_at: datetime
    end_at: datetime
    reason: str


class OverrideRequest(BaseModel):
    class_id: str
    room_id: str
    weekday: int = Field(ge=0, le=6)
    start_minute: int = Field(ge=0, lt=1440)


class OutputModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)