from app.models import AuditLog


def record_audit(
    db,
    action: str,
    entity_type: str,
    entity_id: str | None = None,
    admin_id: str | None = None,
    details: dict | None = None
):
    entry = AuditLog(
        admin_id=admin_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details or {}
    )

    db.add(entry)
    db.flush()

    return entry