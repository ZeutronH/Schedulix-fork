from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Admin
from app.security import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def get_current_admin(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    admin_id = decode_access_token(token)

    if not admin_id:
        raise HTTPException(401, "Invalid or expired token")

    admin = db.get(Admin, admin_id)

    if not admin or not admin.active:
        raise HTTPException(401, "Administrator account unavailable")

    return admin