from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache


class Settings(BaseSettings):
    APP_NAME: str = "Schedulix"
    ENVIRONMENT: str = "development"

    SECRET_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    DATABASE_URL: str
    REDIS_URL: str = "redis://localhost:6379/0"

    CORS_ORIGINS: str = "http://localhost:5173"

    UNIVERSITY_NAME: str = "Your University"
    UNIVERSITY_LOGO: str = ""

    SCHEDULING_MODE: str = "HYBRID"
    PRIORITY_WEIGHT: float = 0.65
    SJF_WEIGHT: float = 0.35
    SCHEDULING_TIME_LIMIT: int = 30

    WHATSAPP_ENABLED: bool = False
    WHATSAPP_ACCESS_TOKEN: str = ""
    WHATSAPP_PHONE_NUMBER_ID: str = ""
    WHATSAPP_BUSINESS_ACCOUNT_ID: str = ""
    WHATSAPP_VERIFY_TOKEN: str = ""
    WHATSAPP_APP_SECRET: str = ""
    WHATSAPP_TEMPLATE_NAME: str = "timetable_notification"
    WHATSAPP_TEMPLATE_LANGUAGE: str = "en"

    MEDIA_DIRECTORY: str = "media"

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore"
    )

    @property
    def cors_list(self):
        return [
            origin.strip()
            for origin in self.CORS_ORIGINS.split(",")
            if origin.strip()
        ]


@lru_cache
def get_settings():
    return Settings()


settings = get_settings()