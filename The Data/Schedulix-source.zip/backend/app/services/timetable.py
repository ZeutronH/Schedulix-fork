from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (
    ScheduledClass,
    Faculty,
    Subject,
    Room,
    Floor,
    Building,
    Section,
    TimetableVersion,
    VersionStatus,
)


def format_minute(value):
    return f"{value // 60:02d}:{value % 60:02d}"


def get_version_classes(db: Session, version_id: str):
    return db.scalars(
        select(ScheduledClass).where(
            ScheduledClass.version_id == version_id
        ).order_by(
            ScheduledClass.weekday,
            ScheduledClass.start_minute
        )
    ).all()


def serialise_class(db, item):
    faculty = db.get(Faculty, item.faculty_id)
    subject = db.get(Subject, item.subject_id)
    room = db.get(Room, item.room_id)
    section = db.get(Section, item.section_id)

    floor = db.get(Floor, room.floor_id) if room else None
    building = db.get(Building, floor.building_id) if floor else None

    return {
        "id": item.id,
        "subject": subject.name if subject else "Unknown",
        "subject_code": subject.code if subject else "",
        "faculty": faculty.full_name if faculty else "Unknown",
        "section": section.name if section else "",
        "room": room.name if room else "",
        "building": building.name if building else "",
        "weekday": item.weekday,
        "start": format_minute(item.start_minute),
        "end": format_minute(item.end_minute),
        "start_minute": item.start_minute,
        "end_minute": item.end_minute,
        "duration": item.end_minute - item.start_minute,
        "session_type": subject.session_type.value if subject else "",
    }


def section_timetable(db, version_id, section_id):
    return [
        serialise_class(db, item)
        for item in get_version_classes(db, version_id)
        if item.section_id == section_id
    ]


def faculty_timetable(db, version_id, faculty_id):
    return [
        serialise_class(db, item)
        for item in get_version_classes(db, version_id)
        if item.faculty_id == faculty_id
    ]


def validate_timetable(db, version_id):
    classes = get_version_classes(db, version_id)

    conflicts = []

    resources = {}

    for item in classes:
        for resource_type, resource_id in (
            ("FACULTY", item.faculty_id),
            ("ROOM", item.room_id),
            ("SECTION", item.section_id),
        ):
            key = (resource_type, resource_id, item.weekday)

            resources.setdefault(key, []).append(item)

    for key, entries in resources.items():
        entries.sort(key=lambda x: x.start_minute)

        for previous, current in zip(entries, entries[1:]):
            if current.start_minute < previous.end_minute:
                conflicts.append({
                    "resource": key[0],
                    "resource_id": key[1],
                    "class_a": previous.id,
                    "class_b": current.id,
                    "reason": "Overlapping assignments"
                })

    return {
        "valid": not conflicts,
        "conflicts": conflicts,
        "class_count": len(classes)
    }