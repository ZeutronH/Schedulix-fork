import os
from datetime import datetime

from PIL import Image, ImageDraw, ImageFont

from sqlalchemy import select

from app.config import settings
from app.models import (
    TimetableVersion,
    TimetableImage,
    Section,
    Faculty,
    Programme,
)
from app.services.timetable import (
    section_timetable,
    faculty_timetable,
)


DAYS = ["Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday", "Sunday"]


def get_font(size, bold=False):
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        if bold else
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"
    ]

    for path in paths:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)

    return ImageFont.load_default()


def generate_timetable_png(
    db,
    version_id,
    recipient_type,
    recipient_id
):
    version = db.get(TimetableVersion, version_id)

    if not version:
        raise ValueError("Timetable version not found")

    if recipient_type == "STUDENT":
        recipient = db.get(Section, recipient_id)

        if not recipient:
            raise ValueError("Section not found")

        classes = section_timetable(
            db, version_id, recipient_id
        )

        heading = f"Section: {recipient.name}"

        programme = db.get(Programme, recipient.programme_id)
        subtitle = programme.name if programme else ""

    elif recipient_type == "FACULTY":
        recipient = db.get(Faculty, recipient_id)

        if not recipient:
            raise ValueError("Faculty not found")

        classes = faculty_timetable(
            db, version_id, recipient_id
        )

        heading = recipient.full_name
        subtitle = recipient.designation or ""

    else:
        raise ValueError("Invalid recipient type")

    width, height = 1800, 1200

    image = Image.new("RGB", (width, height), "#F7F8FC")
    draw = ImageDraw.Draw(image)

    font_title = get_font(42, True)
    font_subtitle = get_font(23)
    font_heading = get_font(21, True)
    font_body = get_font(17)

    draw.rounded_rectangle(
        (30, 30, width - 30, 200),
        radius=24,
        fill="#172554"
    )

    draw.text(
        (65, 55),
        settings.UNIVERSITY_NAME,
        fill="white",
        font=font_title
    )

    draw.text(
        (65, 115),
        heading,
        fill="#DBEAFE",
        font=font_heading
    )

    draw.text(
        (65, 155),
        f"{subtitle} | Version {version.version_number}",
        fill="white",
        font=font_subtitle
    )

    left, top = 35, 245
    day_width = 245
    row_height = 130
    time_width = 130

    draw.rounded_rectangle(
        (left, top, width - 35, height - 110),
        radius=16,
        fill="white",
        outline="#DCE2ED",
        width=2
    )

    draw.rectangle(
        (left, top, width - 35, top + 70),
        fill="#E8EDFA"
    )

    draw.text(
        (left + 15, top + 20),
        "DAY",
        font=font_heading,
        fill="#172554"
    )

    for day in range(7):
        x = left + time_width + day * day_width

        if x + day_width > width - 35:
            break

        draw.text(
            (x + 12, top + 20),
            DAYS[day],
            font=font_heading,
            fill="#172554"
        )

    for day in range(7):
        x = left + 10
        y = top + 85 + day * row_height

        if y + row_height > height - 110:
            break

        draw.text(
            (x, y + 10),
            DAYS[day],
            font=font_heading,
            fill="#172554"
        )

        day_classes = [
            c for c in classes
            if c["weekday"] == day
        ]

        day_classes.sort(key=lambda c: c["start_minute"])

        if not day_classes:
            draw.text(
                (left + time_width + day * day_width + 10, y + 15),
                "No classes",
                font=font_body,
                fill="#94A3B8"
            )
            continue

        for index, item in enumerate(day_classes):
            column = index % 6
            row = index // 6

            cell_x = (
                left + time_width
                + day * day_width
                + column * 2
            )

            cell_y = y + row * 35

            # Display all classes in a compact daily list.
            text = (
                f"{item['start']}-{item['end']} "
                f"{item['subject']}\n"
                f"{item['faculty']} | {item['room']}"
            )

            draw.text(
                (cell_x + 5, cell_y + 5),
                text,
                font=font_body,
                fill="#334155",
                spacing=4
            )

    draw.text(
        (45, height - 75),
        f"Generated: {datetime.now():%d %b %Y} "
        f"| Version: {version.version_number} "
        f"| Schedulix",
        font=font_subtitle,
        fill="#64748B"
    )

    directory = os.path.join(
        settings.MEDIA_DIRECTORY,
        "timetables",
        version_id
    )

    os.makedirs(directory, exist_ok=True)

    filename = f"{recipient_type.lower()}_{recipient_id}.png"
    path = os.path.join(directory, filename)

    image.save(path, "PNG", optimize=True)

    record = TimetableImage(
        version_id=version_id,
        recipient_type=recipient_type,
        recipient_id=recipient_id,
        file_path=path
    )

    db.add(record)
    db.flush()

    return record