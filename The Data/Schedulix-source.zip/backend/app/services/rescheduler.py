from sqlalchemy import select

from app.models import (
    TimetableVersion,
    ScheduledClass,
    FacultyAssignment,
    VersionStatus,
    ReschedulingEvent,
)

from app.services.scheduler import HybridScheduler
from app.services.timetable import validate_timetable


class Rescheduler:

    def __init__(self, db):
        self.db = db

    def create_proposal(
        self,
        old_version_id,
        reason,
        admin_id=None
    ):
        old = self.db.get(
            TimetableVersion,
            old_version_id
        )

        if not old:
            raise ValueError("Original timetable not found")

        if old.status != VersionStatus.PUBLISHED:
            raise ValueError(
                "Only published timetables can be rescheduled"
            )

        # Lock the old version so concurrent rescheduling requests
        # cannot independently replace the same publication.
        self.db.execute(
            select(TimetableVersion)
            .where(TimetableVersion.id == old_version_id)
            .with_for_update()
        )

        new_version = TimetableVersion(
            version_number=old.version_number + 1,
            status=VersionStatus.DRAFT,
            algorithm=old.algorithm,
            priority_weight=old.priority_weight,
            sjf_weight=old.sjf_weight,
            created_by=admin_id
        )

        self.db.add(new_version)
        self.db.flush()

        scheduler = HybridScheduler(
            self.db,
            mode=old.algorithm,
            priority_weight=old.priority_weight,
            sjf_weight=old.sjf_weight
        )

        result = scheduler.solve()

        for index, item in enumerate(result["classes"]):
            self.db.add(
                ScheduledClass(
                    version_id=new_version.id,
                    assignment_id=item["assignment_id"],
                    faculty_id=item["faculty_id"],
                    subject_id=item["subject_id"],
                    section_id=item["section_id"],
                    room_id=item["room_id"],
                    weekday=item["weekday"],
                    start_minute=item["start_minute"],
                    end_minute=item["end_minute"],
                    session_number=index + 1
                )
            )

        self.db.flush()

        validation = validate_timetable(
            self.db,
            new_version.id
        )

        event = ReschedulingEvent(
            old_version_id=old_version_id,
            new_version_id=new_version.id,
            reason=reason,
            affected_classes=[
                c.id for c in self.db.scalars(
                    select(ScheduledClass).where(
                        ScheduledClass.version_id == old_version_id
                    )
                ).all()
            ],
            status=(
                "PROPOSED"
                if validation["valid"]
                and not result["unscheduled"]
                else "NEEDS_REVIEW"
            )
        )

        self.db.add(event)

        new_version.statistics = {
            **result["statistics"],
            "validation": validation,
            "unscheduled": result["unscheduled"]
        }

        return {
            "version_id": new_version.id,
            "event_id": event.id,
            "solver": result["status"],
            "validation": validation,
            "unscheduled": result["unscheduled"],
            "status": event.status
        }