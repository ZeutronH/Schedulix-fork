from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from time import monotonic

from ortools.sat.python import cp_model

from sqlalchemy import select

from app.models import (
    FacultyAssignment,
    Faculty,
    Subject,
    Section,
    Room,
    Floor,
    Building,
    RoomType,
    AvailabilityBlock,
    AvailabilityType,
    FacultyAvailability,
    ScheduledClass,
    SchedulingDemand,
    SessionType,
)


@dataclass
class Job:
    assignment_id: str
    faculty_id: str
    subject_id: str
    section_id: str
    duration: int
    priority: int
    sessions: int
    capacity: int
    room_type: str
    subject_name: str
    faculty_name: str
    session_type: str


class HybridScheduler:

    def __init__(
        self,
        db,
        mode="HYBRID",
        priority_weight=0.65,
        sjf_weight=0.35,
        weekdays=None,
        day_start=480,
        day_end=1080,
        time_limit=30
    ):
        self.db = db
        self.mode = mode.upper()

        if self.mode not in {"HYBRID", "PRIORITY", "SJF"}:
            raise ValueError("Invalid scheduling mode")

        if priority_weight < 0 or sjf_weight < 0:
            raise ValueError("Weights cannot be negative")

        if abs(priority_weight + sjf_weight - 1.0) > 1e-6:
            raise ValueError("Scheduling weights must sum to 1")

        self.priority_weight = priority_weight
        self.sjf_weight = sjf_weight
        self.weekdays = weekdays or [0, 1, 2, 3, 4, 5]
        self.day_start = day_start
        self.day_end = day_end
        self.time_limit = time_limit

    def load_jobs(self):
        assignments = self.db.scalars(
            select(FacultyAssignment).where(
                FacultyAssignment.active.is_(True)
            )
        ).all()

        jobs = []

        for a in assignments:
            faculty = self.db.get(Faculty, a.faculty_id)
            subject = self.db.get(Subject, a.subject_id)
            section = self.db.get(Section, a.section_id)

            if not faculty or not subject or not section:
                continue

            if not faculty.active:
                continue

            for session in range(a.sessions_per_week):
                jobs.append(
                    Job(
                        assignment_id=a.id,
                        faculty_id=faculty.id,
                        subject_id=subject.id,
                        section_id=section.id,
                        duration=a.duration_minutes,
                        priority=a.priority,
                        sessions=a.sessions_per_week,
                        capacity=max(
                            a.required_capacity,
                            section.student_count
                        ),
                        room_type=a.required_room_type.value,
                        subject_name=subject.name,
                        faculty_name=faculty.full_name,
                        session_type=subject.session_type.value,
                    )
                )

        return jobs

    @staticmethod
    def score(job, min_duration, max_duration):
        priority_score = job.priority / 10

        if max_duration == min_duration:
            sjf_score = 1.0
        else:
            sjf_score = (
                (max_duration - job.duration)
                / (max_duration - min_duration)
            )

        return (
            0.65 * priority_score +
            0.35 * sjf_score
        )

    def get_score(self, job, min_duration, max_duration):
        priority_score = job.priority / 10

        sjf_score = (
            1.0 if max_duration == min_duration
            else (max_duration - job.duration) /
                 (max_duration - min_duration)
        )

        if self.mode == "PRIORITY":
            return priority_score

        if self.mode == "SJF":
            return sjf_score

        return (
            self.priority_weight * priority_score
            + self.sjf_weight * sjf_score
        )

    def load_rooms(self):
        rooms = self.db.scalars(
            select(Room).where(Room.available.is_(True))
        ).all()

        return [
            room for room in rooms
            if (
                (floor := self.db.get(Floor, room.floor_id))
                and
                (building := self.db.get(Building, floor.building_id))
                and building.available
            )
        ]

    def _is_teacher_available(self, job, day, start, end):
        records = self.db.scalars(
            select(FacultyAvailability).where(
                FacultyAvailability.faculty_id == job.faculty_id,
                FacultyAvailability.weekday == day
            )
        ).all()

        if records and not any(
            r.available
            and self._minute(r.start_time) <= start
            and self._minute(r.end_time) >= end
            for r in records
        ):
            return False

        return True

    @staticmethod
    def _minute(value):
        return value.hour * 60 + value.minute

    def _blocked(self, resource_type, resource_id, day, start, end):
        blocks = self.db.scalars(
            select(AvailabilityBlock).where(
                AvailabilityBlock.resource_type == resource_type,
                AvailabilityBlock.resource_id == resource_id
            )
        ).all()

        for block in blocks:
            if block.start_at.weekday() != day:
                continue

            block_start = self._minute(block.start_at.time())
            block_end = self._minute(block.end_at.time())

            if start < block_end and block_start < end:
                return True

        return False

    def _room_suitable(self, job, room):
        return (
            room.available
            and room.capacity >= job.capacity
            and room.room_type.value == job.room_type
        )

    def solve(self):
        started = monotonic()

        jobs = self.load_jobs()
        rooms = self.load_rooms()

        if not jobs:
            return {
                "status": "EMPTY",
                "classes": [],
                "unscheduled": [],
                "quality_score": 0,
                "statistics": {}
            }

        if not rooms:
            return {
                "status": "INFEASIBLE",
                "classes": [],
                "unscheduled": [
                    {
                        "assignment_id": j.assignment_id,
                        "reason": "No available rooms"
                    }
                    for j in jobs
                ],
                "quality_score": 0,
                "statistics": {}
            }

        min_duration = min(j.duration for j in jobs)
        max_duration = max(j.duration for j in jobs)

        model = cp_model.CpModel()

        candidates = []
        by_job = defaultdict(list)
        by_resource = defaultdict(list)

        # Each candidate represents one feasible placement.
        for ji, job in enumerate(jobs):

            suitable_rooms = [
                r for r in rooms
                if self._room_suitable(job, r)
            ]

            for day in self.weekdays:

                for start in range(
                    self.day_start,
                    self.day_end - job.duration + 1,
                    15
                ):
                    end = start + job.duration

                    if not self._is_teacher_available(
                        job, day, start, end
                    ):
                        continue

                    if self._blocked(
                        AvailabilityType.FACULTY,
                        job.faculty_id,
                        day, start, end
                    ):
                        continue

                    for room in suitable_rooms:

                        if self._blocked(
                            AvailabilityType.ROOM,
                            room.id,
                            day, start, end
                        ):
                            continue

                        floor = self.db.get(Floor, room.floor_id)

                        if self._blocked(
                            AvailabilityType.FLOOR,
                            floor.id,
                            day, start, end
                        ):
                            continue

                        if self._blocked(
                            AvailabilityType.BUILDING,
                            floor.building_id,
                            day, start, end
                        ):
                            continue

                        var = model.new_bool_var(
                            f"j{ji}_d{day}_t{start}_r{room.id}"
                        )

                        candidate = {
                            "var": var,
                            "job": ji,
                            "day": day,
                            "start": start,
                            "end": end,
                            "room": room.id,
                            "faculty": job.faculty_id,
                            "section": job.section_id,
                            "duration": job.duration,
                            "priority": job.priority
                        }

                        candidates.append(candidate)
                        by_job[ji].append(candidate)

                        for resource in (
                            ("faculty", job.faculty_id),
                            ("section", job.section_id),
                            ("room", room.id)
                        ):
                            by_resource[resource].append(candidate)

            # Each requested class must be placed exactly once.
            if by_job[ji]:
                model.add(
                    sum(c["var"] for c in by_job[ji]) == 1
                )
            else:
                # This job cannot be placed. Other jobs can still be
                # scheduled, and the API will report the failure.
                pass

        # At most one candidate per physical resource at any instant.
        # Pairwise non-overlap constraints.
        for resource, options in by_resource.items():
            for i in range(len(options)):
                a = options[i]

                for j in range(i + 1, len(options)):
                    b = options[j]

                    if a["job"] == b["job"]:
                        continue

                    if a["day"] != b["day"]:
                        continue

                    if (
                        a["start"] < b["end"]
                        and b["start"] < a["end"]
                    ):
                        model.add(
                            a["var"] + b["var"] <= 1
                        )

        # A laboratory session is represented as one continuous
        # interval, not several independent hourly sessions.

        # Objective: hybrid score, with a small deterministic
        # preference for earlier placement.
        objective_terms = []

        for candidate in candidates:
            job = jobs[candidate["job"]]

            score = self.get_score(
                job,
                min_duration,
                max_duration
            )

            score_units = int(score * 10000)

            # Keep the score dominant. The time tie-breaker is small.
            time_penalty = candidate["start"] - self.day_start

            objective_terms.append(
                candidate["var"] *
                (score_units * 1000 - time_penalty)
            )

        model.maximize(sum(objective_terms))

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = self.time_limit
        solver.parameters.num_search_workers = 8

        status = solver.solve(model)

        status_name = solver.status_name(status)

        if status not in (
            cp_model.OPTIMAL,
            cp_model.FEASIBLE
        ):
            return {
                "status": status_name,
                "classes": [],
                "unscheduled": [
                    {
                        "assignment_id": job.assignment_id,
                        "reason": (
                            "No feasible placement exists under "
                            "the supplied constraints"
                            if not by_job[i]
                            else "Solver could not find a feasible solution"
                        )
                    }
                    for i, job in enumerate(jobs)
                ],
                "quality_score": 0,
                "statistics": {
                    "solver_status": status_name,
                    "candidate_count": len(candidates),
                    "elapsed_seconds": monotonic() - started
                }
            }

        output = []
        unscheduled = []

        for ji, job in enumerate(jobs):

            selected = next(
                (
                    c for c in by_job[ji]
                    if solver.value(c["var"]) == 1
                ),
                None
            )

            if selected is None:
                unscheduled.append({
                    "assignment_id": job.assignment_id,
                    "reason": "No selected feasible placement"
                })
                continue

            output.append({
                "assignment_id": job.assignment_id,
                "faculty_id": job.faculty_id,
                "subject_id": job.subject_id,
                "section_id": job.section_id,
                "room_id": selected["room"],
                "weekday": selected["day"],
                "start_minute": selected["start"],
                "end_minute": selected["end"],
                "duration": job.duration,
                "priority": job.priority,
                "subject": job.subject_name,
                "faculty": job.faculty_name,
                "session_type": job.session_type,
            })

        score_sum = sum(
            self.get_score(j, min_duration, max_duration)
            for j in jobs
        )

        placed_score = sum(
            self.get_score(
                jobs[next(
                    i for i, j in enumerate(jobs)
                    if j.assignment_id == item["assignment_id"]
                )],
                min_duration,
                max_duration
            )
            for item in output
        )

        quality = (
            100 * placed_score / score_sum
            if score_sum else 0
        )

        return {
            "status": status_name,
            "classes": output,
            "unscheduled": unscheduled,
            "quality_score": round(quality, 2),
            "statistics": {
                "total_jobs": len(jobs),
                "scheduled": len(output),
                "unscheduled": len(unscheduled),
                "candidate_count": len(candidates),
                "objective_value": solver.objective_value,
                "solver_status": status_name,
                "elapsed_seconds": round(
                    monotonic() - started, 3
                )
            }
        }