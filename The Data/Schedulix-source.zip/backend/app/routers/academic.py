from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_admin
from app.models import (
    Department,
    Programme,
    AcademicYear,
    Semester,
    Section,
    Subject,
    Student,
    Faculty,
    FacultyAssignment,
    Enrolment,
)
from app.schemas import (
    DepartmentCreate,
    ProgrammeCreate,
    AcademicYearCreate,
    SectionCreate,
    SubjectCreate,
    StudentCreate,
    FacultyCreate,
    AssignmentCreate,
)
from app.audit import record_audit

router = APIRouter(
    prefix="/academic",
    tags=["Academic Management"],
    dependencies=[Depends(get_current_admin)]
)


def create_record(db, model, data, admin, entity):
    record = model(**data.model_dump())
    db.add(record)
    db.flush()

    record_audit(
        db,
        "CREATE",
        entity,
        record.id,
        admin.id,
        data.model_dump(mode="json")
    )

    db.commit()
    db.refresh(record)

    return record


@router.post("/departments")
def create_department(
    data: DepartmentCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    return create_record(
        db, Department, data, admin, "Department"
    )


@router.get("/departments")
def departments(db: Session = Depends(get_db)):
    return db.query(Department).all()


@router.post("/programmes")
def create_programme(
    data: ProgrammeCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    if not db.get(Department, data.department_id):
        raise HTTPException(404, "Department not found")

    return create_record(
        db, Programme, data, admin, "Programme"
    )


@router.get("/programmes")
def programmes(db: Session = Depends(get_db)):
    return db.query(Programme).all()


@router.post("/academic-years")
def create_year(
    data: AcademicYearCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    if data.end_date <= data.start_date:
        raise HTTPException(400, "Invalid academic year dates")

    return create_record(
        db, AcademicYear, data, admin, "AcademicYear"
    )


@router.post("/semesters")
def create_semester(
    programme_id: str,
    academic_year_id: str,
    number: int,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    if not db.get(Programme, programme_id):
        raise HTTPException(404, "Programme not found")

    if not db.get(AcademicYear, academic_year_id):
        raise HTTPException(404, "Academic year not found")

    if not 1 <= number <= 12:
        raise HTTPException(400, "Invalid semester")

    return create_record(
        db,
        Semester,
        type("Data", (), {
            "model_dump": lambda self: {
                "programme_id": programme_id,
                "academic_year_id": academic_year_id,
                "number": number
            }
        })(),
        admin,
        "Semester"
    )


@router.post("/sections")
def create_section(
    data: SectionCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    if not db.get(Semester, data.semester_id):
        raise HTTPException(404, "Semester not found")

    return create_record(
        db, Section, data, admin, "Section"
    )


@router.get("/sections")
def sections(db: Session = Depends(get_db)):
    return db.query(Section).all()


@router.post("/subjects")
def create_subject(
    data: SubjectCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    return create_record(
        db, Subject, data, admin, "Subject"
    )


@router.get("/subjects")
def subjects(db: Session = Depends(get_db)):
    return db.query(Subject).all()


@router.post("/faculty")
def create_faculty(
    data: FacultyCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    return create_record(
        db, Faculty, data, admin, "Faculty"
    )


@router.get("/faculty")
def faculty(db: Session = Depends(get_db)):
    return db.query(Faculty).all()


@router.post("/students")
def create_student(
    data: StudentCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    return create_record(
        db, Student, data, admin, "Student"
    )


@router.get("/students")
def students(db: Session = Depends(get_db)):
    return db.query(Student).all()


@router.post("/assignments")
def create_assignment(
    data: AssignmentCreate,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    faculty = db.get(Faculty, data.faculty_id)
    subject = db.get(Subject, data.subject_id)
    section = db.get(Section, data.section_id)

    if not all((faculty, subject, section)):
        raise HTTPException(404, "Academic entity not found")

    if not faculty.active:
        raise HTTPException(400, "Faculty is inactive")

    # This assignment is the explicit subject eligibility record.
    return create_record(
        db, FacultyAssignment, data, admin, "FacultyAssignment"
    )


@router.get("/assignments")
def assignments(db: Session = Depends(get_db)):
    return db.query(FacultyAssignment).all()


@router.post("/enrolments")
def enrol_student(
    student_id: str,
    section_id: str,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    if not db.get(Student, student_id):
        raise HTTPException(404, "Student not found")

    section = db.get(Section, section_id)

    if not section:
        raise HTTPException(404, "Section not found")

    existing = db.query(Enrolment).filter_by(
        student_id=student_id,
        section_id=section_id
    ).first()

    if existing:
        raise HTTPException(409, "Already enrolled")

    enrolment = Enrolment(
        student_id=student_id,
        section_id=section_id
    )

    db.add(enrolment)
    db.commit()

    return {"status": "ENROLLED"}