from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.dependencies import get_current_admin
from app.models import (
    TimetableVersion,
    ScheduledClass,
    VersionStatus,
    Approval,
    Section,
    Faculty,
    Student,
    Enrolment,
    WhatsAppNotification,
    TimetableImage,
    DeliveryStatus,
)
from app.schemas import ScheduleRequest, ApprovalRequest
from app.services.scheduler import HybridScheduler
from app.services.timetable import (
    validate_timetable,
    section_timetable,
    faculty_timetable,
)
from app.services.image_generator import generate_timetable_png
from app.services.rescheduler import Rescheduler
from app.services.whatsapp import WhatsAppService
from app.tasks.jobs import generate_timetable as generate_task
from app.tasks.jobs import deliver_notification
from app.audit import record_audit

router = APIRouter(
    prefix="/scheduling",
    tags=["Scheduling"],
    dependencies=[Depends(get_current_admin)]
)


@router.post("/generate")
def generate(
    request: ScheduleRequest,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    if abs(
        request.priority_weight + request.sjf_weight - 1
    ) > 0.000001:
        raise HTTPException(400, "Weights must sum to 1")

    if any(d < 0 or d > 6 for d in request.weekdays):
        raise HTTPException(400, "Invalid weekday")

    start = request.day_start.hour * 60 + request.day_start.minute
    end = request.day_end.hour * 60 + request.day_end.minute

    if end <= start:
        raise HTTPException(400, "Invalid working hours")

    # Acquire a PostgreSQL transaction-level advisory lock.
    # Only one generation operation may run for this university.
    db.execute(
        select(
            __import__("sqlalchemy").func.pg_advisory_xact_lock(741852)
        )
    )

    scheduler = HybridScheduler(
        db,
        mode=request.mode,
        priority_weight=request.priority_weight,
        sjf_weight=request.sjf_weight,
        weekdays=request.weekdays,
        day_start=start,
        day_end=end,
        time_limit=request.time_limit_seconds
    )

    result = scheduler.solve()

    if result["status"] not in ("OPTIMAL", "FEASIBLE"):
        return result

    latest = db.scalar(
        select(TimetableVersion.version_number)
        .order_by(TimetableVersion.version_number.desc())
        .limit(1)
    ) or 0

    version = TimetableVersion(
        version_number=latest + 1,
        status=VersionStatus.DRAFT,
        algorithm=request.mode,
        priority_weight=request.priority_weight,
        sjf_weight=request.sjf_weight,
        quality_score=result["quality_score"],
        created_by=admin.id,
        statistics=result["statistics"]
    )

    db.add(version)
    db.flush()

    for index, item in enumerate(result["classes"]):
        db.add(
            ScheduledClass(
                version_id=version.id,
                assignment_id=item["assignment_id"],
                faculty_id=item["faculty_id"],
                section_id=item["section_id"],
                subject_id=item["subject_id"],
                room_id=item["room_id"],
                weekday=item["weekday"],
                start_minute=item["start_minute"],
                end_minute=item["end_minute"],
                session_number=index + 1
            )
        )

    db.flush()

    validation = validate_timetable(db, version.id)

    version.statistics = {
        **result["statistics"],
        "validation": validation,
        "unscheduled": result["unscheduled"]
    }

    record_audit(
        db,
        "TIMETABLE_GENERATED",
        "TimetableVersion",
        version.id,
        admin.id,
        version.statistics
    )

    db.commit()

    return {
        "version_id": version.id,
        "version_number": version.version_number,
        "status": version.status.value,
        "quality_score": version.quality_score,
        "solver": result["status"],
        "validation": validation,
        "unscheduled": result["unscheduled"],
        "statistics": version.statistics
    }


@router.post("/generate-async")
def generate_async(
    request: ScheduleRequest,
    admin=Depends(get_current_admin)
):
    if abs(
        request.priority_weight + request.sjf_weight - 1
    ) > 0.000001:
        raise HTTPException(400, "Weights must sum to 1")

    start = request.day_start.hour * 60 + request.day_start.minute
    end = request.day_end.hour * 60 + request.day_end.minute

    if end <= start:
        raise HTTPException(400, "Invalid working hours")

    task = generate_task.delay({
        "mode": request.mode,
        "priority_weight": request.priority_weight,
        "sjf_weight": request.sjf_weight,
        "weekdays": request.weekdays,
        "day_start": start,
        "day_end": end,
        "time_limit": request.time_limit_seconds
    })

    return {
        "task_id": task.id,
        "status": "QUEUED"
    }


@router.get("/task/{task_id}")
def task_status(
    task_id: str,
    admin=Depends(get_current_admin)
):
    from app.tasks.celery_app import celery

    result = celery.AsyncResult(task_id)

    return {
        "task_id": task_id,
        "status": result.status,
        "result": result.result if result.ready() else None
    }


@router.get("/versions")
def versions(db: Session = Depends(get_db)):
    return db.query(TimetableVersion).order_by(
        TimetableVersion.version_number.desc()
    ).all()


@router.get("/versions/{version_id}")
def version_details(
    version_id: str,
    db: Session = Depends(get_db)
):
    version = db.get(TimetableVersion, version_id)

    if not version:
        raise HTTPException(404, "Version not found")

    return {
        "version": version,
        "validation": validate_timetable(db, version_id)
    }


@router.get("/versions/{version_id}/section/{section_id}")
def section_schedule(
    version_id: str,
    section_id: str,
    db: Session = Depends(get_db)
):
    return section_timetable(db, version_id, section_id)


@router.get("/versions/{version_id}/faculty/{faculty_id}")
def faculty_schedule(
    version_id: str,
    faculty_id: str,
    db: Session = Depends(get_db)
):
    return faculty_timetable(db, version_id, faculty_id)


@router.post("/versions/{version_id}/approve")
def approve(
    version_id: str,
    data: ApprovalRequest,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    version = db.execute(
        select(TimetableVersion)
        .where(TimetableVersion.id == version_id)
        .with_for_update()
    ).scalar_one_or_none()

    if not version:
        raise HTTPException(404, "Version not found")

    if version.status != VersionStatus.DRAFT:
        raise HTTPException(409, "Version is not a draft")

    validation = validate_timetable(db, version_id)

    if not validation["valid"]:
        raise HTTPException(409, detail=validation)

    if version.statistics.get("unscheduled"):
        raise HTTPException(
            409,
            "Cannot approve a timetable with unscheduled classes"
        )

    version.status = VersionStatus.APPROVED
    version.approved_by = admin.id

    db.add(
        Approval(
            version_id=version_id,
            admin_id=admin.id,
            decision="APPROVED",
            comments=data.comments
        )
    )

    record_audit(
        db, "TIMETABLE_APPROVED",
        "TimetableVersion", version_id, admin.id
    )

    db.commit()

    return {"status": "APPROVED"}


@router.post("/versions/{version_id}/publish")
def publish(
    version_id: str,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    version = db.execute(
        select(TimetableVersion)
        .where(TimetableVersion.id == version_id)
        .with_for_update()
    ).scalar_one_or_none()

    if not version:
        raise HTTPException(404, "Version not found")

    if version.status != VersionStatus.APPROVED:
        raise HTTPException(
            409, "Only approved versions can be published"
        )

    validation = validate_timetable(db, version_id)

    if not validation["valid"]:
        raise HTTPException(409, detail=validation)

    # Lock publication changes in one transaction.
    previous = db.scalars(
        select(TimetableVersion)
        .where(TimetableVersion.status == VersionStatus.PUBLISHED)
        .with_for_update()
    ).all()

    for old in previous:
        old.status = VersionStatus.SUPERSEDED

    version.status = VersionStatus.PUBLISHED
    version.published_at = datetime.utcnow()

    record_audit(
        db,
        "TIMETABLE_PUBLISHED",
        "TimetableVersion",
        version_id,
        admin.id
    )

    db.commit()

    return {
        "status": "PUBLISHED",
        "version_id": version_id
    }


@router.post("/versions/{version_id}/reschedule")
def reschedule(
    version_id: str,
    reason: str,
    db: Session = Depends(get_db),
    admin=Depends(get_current_admin)
):
    try:
        result = Rescheduler(db).create_proposal(
            version_id,
            reason,
            admin.id
        )

        db.commit()
        return result

    except Exception:
        db.rollback()
        raise


@router.post("/versions/{version_id}/images")
def generate_images(
    version_id: str,
    db: Session = Depends(get_db)
):
    version = db.get(TimetableVersion, version_id)

    if not version:
        raise HTTPException(404, "Version not found")

    if version.status not in (
        VersionStatus.APPROVED,
        VersionStatus.PUBLISHED
    ):
        raise HTTPException(409, "Version must be approved first")

    output = []

    sections = db.scalars(
        select(Section).distinct()
        .join(ScheduledClass,
              ScheduledClass.section_id == Section.id)
        .where(ScheduledClass.version_id == version_id)
    ).all()

    faculty = db.scalars(
        select(Faculty).distinct()
        .join(ScheduledClass,
              ScheduledClass.faculty_id == Faculty.id)
        .where(ScheduledClass.version_id == version_id)
    ).all()

    try:
        for section in sections:
            image = generate_timetable_png(
                db, version_id, "STUDENT", section.id
            )
            output.append({
                "recipient_type": "STUDENT",
                "recipient_id": section.id,
                "image_id": image.id
            })

        for teacher in faculty:
            image = generate_timetable_png(
                db, version_id, "FACULTY", teacher.id
            )
            output.append({
                "recipient_type": "FACULTY",
                "recipient_id": teacher.id,
                "image_id": image.id
            })

        db.commit()

    except Exception:
        db.rollback()
        raise

    return {
        "generated": len(output),
        "images": output
    }


@router.post("/versions/{version_id}/notify")
def notify(
    version_id: str,
    db: Session = Depends(get_db)
):
    version = db.get(TimetableVersion, version_id)

    if not version or version.status != VersionStatus.PUBLISHED:
        raise HTTPException(409, "Version must be published")

    service = WhatsAppService()

    if not service.enabled:
        return {
            "status": "NOT_CONFIGURED",
            "message": "WhatsApp Cloud API credentials are missing"
        }

    images = db.scalars(
        select(TimetableImage).where(
            TimetableImage.version_id == version_id
        )
    ).all()

    queued = []

    for image in images:

        if image.recipient_type == "STUDENT":
            recipients = db.scalars(
                select(Student)
                .join(Enrolment)
                .where(
                    Enrolment.section_id == image.recipient_id,
                    Enrolment.active.is_(True),
                    Student.active.is_(True),
                    Student.whatsapp_consent.is_(True)
                )
            ).all()

        else:
            recipients = db.scalars(
                select(Faculty).where(
                    Faculty.id == image.recipient_id,
                    Faculty.active.is_(True),
                    Faculty.whatsapp_consent.is_(True)
                )
            ).all()

        for person in recipients:
            phone = person.whatsapp_number

            if not phone:
                continue

            from app.tasks.jobs import deliver_notification

            notification = WhatsAppNotification(
                image_id=image.id,
                recipient_type=image.recipient_type,
                recipient_id=person.id,
                phone_number=phone,
                status=DeliveryStatus.QUEUED
            )

            db.add(notification)
            db.flush()

            queued.append(notification.id)

    db.commit()

    for notification_id in queued:
        deliver_notification.delay(notification_id)

    return {
        "status": "QUEUED",
        "recipient_count": len(queued)
    }