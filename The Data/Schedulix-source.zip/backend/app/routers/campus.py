from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_admin
from app.models import Building, Floor, Room, CampusNode, CampusEdge
from app.schemas import (
    RoomCreate,
    CampusNodeCreate,
    CampusEdgeCreate,
)
from app.services.graph import CampusGraph

router = APIRouter(
    prefix="/campus",
    tags=["Campus"],
    dependencies=[Depends(get_current_admin)]
)


@router.post("/buildings")
def create_building(
    name: str,
    code: str,
    db: Session = Depends(get_db)
):
    building = Building(name=name, code=code)
    db.add(building)
    db.commit()
    db.refresh(building)
    return building


@router.post("/floors")
def create_floor(
    building_id: str,
    name: str,
    level: int,
    db: Session = Depends(get_db)
):
    if not db.get(Building, building_id):
        raise HTTPException(404, "Building not found")

    floor = Floor(
        building_id=building_id,
        name=name,
        level=level
    )

    db.add(floor)
    db.commit()
    db.refresh(floor)
    return floor


@router.post("/rooms")
def create_room(
    data: RoomCreate,
    db: Session = Depends(get_db)
):
    if not db.get(Floor, data.floor_id):
        raise HTTPException(404, "Floor not found")

    room = Room(**data.model_dump())
    db.add(room)
    db.commit()
    db.refresh(room)
    return room


@router.get("/rooms")
def rooms(db: Session = Depends(get_db)):
    return db.query(Room).all()


@router.post("/nodes")
def create_node(
    data: CampusNodeCreate,
    db: Session = Depends(get_db)
):
    node = CampusNode(**data.model_dump())
    db.add(node)
    db.commit()
    db.refresh(node)
    return node


@router.post("/edges")
def create_edge(
    data: CampusEdgeCreate,
    db: Session = Depends(get_db)
):
    if not db.get(CampusNode, data.source_id):
        raise HTTPException(404, "Source node not found")

    if not db.get(CampusNode, data.target_id):
        raise HTTPException(404, "Target node not found")

    edge = CampusEdge(**data.model_dump())
    db.add(edge)
    db.commit()
    db.refresh(edge)
    return edge


@router.get("/path")
def shortest_path(
    source: str,
    target: str,
    accessible_only: bool = False,
    db: Session = Depends(get_db)
):
    graph = CampusGraph(db)
    graph.load()

    return graph.shortest_path(
        source,
        target,
        accessible_only
    )


@router.get("/nearest-rooms/{source_room_id}")
def nearest_rooms(
    source_room_id: str,
    accessible_only: bool = False,
    db: Session = Depends(get_db)
):
    if not db.get(Room, source_room_id):
        raise HTTPException(404, "Source room not found")

    graph = CampusGraph(db)
    graph.load()

    candidates = db.query(Room).filter(
        Room.available.is_(True)
    ).all()

    return graph.nearest_rooms(
        source_room_id,
        candidates,
        accessible_only
    )