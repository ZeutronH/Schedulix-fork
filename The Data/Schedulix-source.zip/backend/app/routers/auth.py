from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Admin
from app.schemas import LoginRequest, TokenResponse
from app.security import (
    verify_password,
    create_access_token,
)

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/login", response_model=TokenResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    admin = db.query(Admin).filter(
        Admin.username == data.username
    ).first()

    if (
        not admin
        or not admin.active
        or not verify_password(data.password, admin.password_hash)
    ):
        raise HTTPException(401, "Invalid credentials")

    return TokenResponse(
        access_token=create_access_token(admin.id)
    )


@router.get("/me")
def me(admin=Depends(__import__(
    "app.dependencies",
    fromlist=["get_current_admin"]
).get_current_admin)):
    return {
        "id": admin.id,
        "username": admin.username,
        "email": admin.email,
        "role": "ADMIN"
    }