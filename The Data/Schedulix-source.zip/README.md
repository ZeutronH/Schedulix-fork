# Schedulix

University Timetable Management System.

## Requirements

- Python 3.12+
- Node.js 22+
- Docker and Docker Compose
- PostgreSQL 17
- Redis 7

## Environment setup

Copy the environment template:

    cp .env.example .env

Generate a secret:

    python -c "import secrets; print(secrets.token_urlsafe(48))"

Put the generated value into SECRET_KEY.

Set an administrator password:

    ADMIN_USERNAME=admin
    ADMIN_EMAIL=admin@example.com
    ADMIN_PASSWORD=your-strong-password

## Start infrastructure

    docker compose up -d db redis

## Backend setup

    cd backend

    python -m venv .venv

Activate the environment.

Linux/macOS:

    source .venv/bin/activate

Windows:

    .venv\Scripts\activate

Install dependencies:

    pip install -r requirements.txt

Run migrations:

    alembic upgrade head

Seed database:

    python -m app.seed

Start FastAPI:

    uvicorn app.main:app --reload --port 8000

## Celery worker

From backend:

    celery -A app.tasks.celery_app worker --loglevel=info

## Frontend

Open another terminal:

    cd frontend

    npm install

    npm run dev

Open:

    http://localhost:5173

## API documentation

    http://localhost:8000/docs

## Run tests

From the backend directory:

    PYTHONPATH=. pytest tests -v

## Docker deployment

From the project root:

    docker compose up --build -d

## Database migration

Create a new migration:

    alembic revision --autogenerate -m "description"

Apply:

    alembic upgrade head

Rollback one revision:

    alembic downgrade -1