import { useEffect, useState } from "react";
import {
  Users, GraduationCap, Building2,
  CalendarDays, BookOpen, AlertTriangle
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar,
  XAxis, YAxis, Tooltip, CartesianGrid
} from "recharts";

import api from "../api";

export default function Dashboard() {
  const [data, setData] = useState<any>({
    departments: [],
    faculty: [],
    students: [],
    versions: [],
    rooms: [],
    sections: []
  });

  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const [departments, faculty, students, versions,
          rooms, sections] = await Promise.all([
          api.get("/academic/departments"),
          api.get("/academic/faculty"),
          api.get("/academic/students"),
          api.get("/scheduling/versions"),
          api.get("/campus/rooms"),
          api.get("/academic/sections")
        ]);

        setData({
          departments: departments.data,
          faculty: faculty.data,
          students: students.data,
          versions: versions.data,
          rooms: rooms.data,
          sections: sections.data
        });
      } catch {
        setError("Unable to load dashboard data.");
      }
    }

    load();
  }, []);

  const cards = [
    { title: "Departments", value: data.departments.length, icon: Building2 },
    { title: "Faculty", value: data.faculty.length, icon: Users },
    { title: "Students", value: data.students.length, icon: GraduationCap },
    { title: "Sections", value: data.sections.length, icon: BookOpen },
    { title: "Rooms", value: data.rooms.length, icon: CalendarDays },
    { title: "Timetable Versions", value: data.versions.length, icon: AlertTriangle }
  ];

  const chartData = data.versions.slice(0, 8).map((v: any) => ({
    name: `V${v.version_number}`,
    score: v.quality_score || 0
  }));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Dashboard</h2>
        <p className="text-sm text-slate-500 mt-1">
          University scheduling overview
        </p>
      </div>

      {error && (
        <div className="bg-red-50 text-red-700 p-4 rounded-lg">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {cards.map(card => {
          const Icon = card.icon;

          return (
            <div key={card.title} className="panel">
              <div className="flex justify-between">
                <div>
                  <p className="text-sm text-slate-500">
                    {card.title}
                  </p>
                  <h3 className="text-3xl font-bold mt-3">
                    {card.value}
                  </h3>
                </div>
                <div className="bg-indigo-50 text-indigo-600 p-3 rounded-xl h-fit">
                  <Icon size={23} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="panel">
        <h3 className="font-semibold mb-5">
          Timetable optimisation quality
        </h3>

        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="score" name="Quality score" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="panel">
        <h3 className="font-semibold mb-4">
          Recent timetable versions
        </h3>

        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>Version</th>
                <th>Algorithm</th>
                <th>Status</th>
                <th>Quality</th>
              </tr>
            </thead>
            <tbody>
              {data.versions.map((v: any) => (
                <tr key={v.id}>
                  <td>V{v.version_number}</td>
                  <td>{v.algorithm}</td>
                  <td>{v.status}</td>
                  <td>{v.quality_score}%</td>
                </tr>
              ))}

              {data.versions.length === 0 && (
                <tr>
                  <td colSpan={4}>No timetable versions generated.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}