import {
  LayoutDashboard, CalendarDays, Users, GraduationCap,
  Building2, BookOpen, Settings, MessageSquare,
  ClipboardList, LogOut, Network, Clock
} from "lucide-react";

interface Props {
  page: string;
  setPage: (page: string) => void;
  logout: () => void;
}

const navigation = [
  { label: "Dashboard", icon: LayoutDashboard },
  { label: "Timetables", icon: CalendarDays },
  { label: "Scheduling", icon: Clock },
  { label: "Departments", icon: Building2 },
  { label: "Students", icon: GraduationCap },
  { label: "Faculty", icon: Users },
  { label: "Subjects", icon: BookOpen },
  { label: "Campus", icon: Network },
  { label: "Availability", icon: ClipboardList },
  { label: "WhatsApp", icon: MessageSquare },
  { label: "Audit Logs", icon: Settings }
];

export default function Sidebar({
  page, setPage, logout
}: Props) {
  return (
    <aside className="w-64 min-h-screen bg-navy text-white p-4 flex flex-col shrink-0">
      <div className="flex items-center gap-3 px-2 py-5">
        <div className="bg-indigo-500 rounded-xl p-2 font-bold">
          S
        </div>
        <div>
          <h1 className="font-bold text-xl">Schedulix</h1>
          <p className="text-xs text-slate-400">University Management</p>
        </div>
      </div>

      <div className="text-xs text-slate-500 uppercase tracking-widest px-3 mt-6 mb-3">
        Workspace
      </div>

      <nav className="space-y-1">
        {navigation.map(item => {
          const Icon = item.icon;

          return (
            <button
              key={item.label}
              onClick={() => setPage(item.label)}
              className={`nav-item ${
                page === item.label ? "active" : ""
              }`}
            >
              <Icon size={18} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="mt-auto pt-5 border-t border-slate-700">
        <button onClick={logout} className="nav-item">
          <LogOut size={18} />
          Sign out
        </button>
      </div>
    </aside>
  );
}