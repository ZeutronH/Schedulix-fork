import { useEffect, useState } from "react";
import api from "../api";
import type {
  TimetableEntry,
  TimetableVersion
} from "../types";

const days = [
  "Monday", "Tuesday", "Wednesday",
  "Thursday", "Friday", "Saturday", "Sunday"
];

export default function Timetable() {
  const [versions, setVersions] = useState<TimetableVersion[]>([]);
  const [sections, setSections] = useState<any[]>([]);
  const [version, setVersion] = useState("");
  const [section, setSection] = useState("");
  const [classes, setClasses] = useState<TimetableEntry[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([
      api.get("/scheduling/versions"),
      api.get("/academic/sections")
    ]).then(([v, s]) => {
      setVersions(v.data);
      setSections(s.data);
    }).catch(() => {
      setError("Unable to load timetable information.");
    });
  }, []);

  async function load() {
    if (!version || !section) return;

    try {
      const response = await api.get(
        `/scheduling/versions/${version}/section/${section}`
      );

      setClasses(response.data);
      setError("");
    } catch {
      setError("Unable to load timetable.");
    }
  }

  async function createImages() {
    await api.post(`/scheduling/versions/${version}/images`);
    alert("Timetable images generated.");
  }

  return (
    <div className="space-y-5">
      <h2 className="text-2xl font-bold">Timetables</h2>

      <div className="panel grid md:grid-cols-3 gap-3">
        <select
          className="field"
          value={version}
          onChange={e => setVersion(e.target.value)}
        >
          <option value="">Select version</option>
          {versions.map(v => (
            <option key={v.id} value={v.id}>
              Version {v.version_number} — {v.status}
            </option>
          ))}
        </select>

        <select
          className="field"
          value={section}
          onChange={e => setSection(e.target.value)}
        >
          <option value="">Select section</option>
          {sections.map(s => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>

        <button className="primary" onClick={load}>
          Load timetable
        </button>
      </div>

      {error && <p className="text-red-600">{error}</p>}

      <div className="panel overflow-x-auto">
        <table className="table min-w-[800px]">
          <thead>
            <tr>
              <th>Day</th>
              <th>Time</th>
              <th>Subject</th>
              <th>Faculty</th>
              <th>Room</th>
              <th>Session</th>
            </tr>
          </thead>
          <tbody>
            {classes.map(item => (
              <tr key={item.id}>
                <td>{days[item.weekday]}</td>
                <td>{item.start} – {item.end}</td>
                <td className="font-semibold">{item.subject}</td>
                <td>{item.faculty}</td>
                <td>{item.room}</td>
                <td>{item.session_type}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {version && (
        <button className="secondary" onClick={createImages}>
          Generate section and faculty PNGs
        </button>
      )}
    </div>
  );
}