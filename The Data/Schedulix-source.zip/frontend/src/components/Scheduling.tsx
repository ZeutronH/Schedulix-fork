import { useState } from "react";
import api from "../api";

export default function Scheduling() {
  const [mode, setMode] = useState("HYBRID");
  const [priority, setPriority] = useState(65);
  const [sjf, setSjf] = useState(35);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const response = await api.post(
        "/scheduling/generate",
        {
          mode,
          priority_weight: priority / 100,
          sjf_weight: sjf / 100,
          weekdays: [0, 1, 2, 3, 4, 5],
          day_start: "08:00:00",
          day_end: "18:00:00",
          time_limit_seconds: 30
        }
      );

      setResult(response.data);
    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
        "Timetable generation failed."
      );
    } finally {
      setLoading(false);
    }
  }

  async function approve() {
    if (!result?.version_id) return;

    await api.post(
      `/scheduling/versions/${result.version_id}/approve`,
      { comments: "Approved through admin dashboard" }
    );

    setResult({
      ...result,
      status: "APPROVED"
    });
  }

  async function publish() {
    if (!result?.version_id) return;

    await api.post(
      `/scheduling/versions/${result.version_id}/publish`
    );

    setResult({
      ...result,
      status: "PUBLISHED"
    });
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">
          Timetable Scheduler
        </h2>
        <p className="text-slate-500 text-sm mt-1">
          Operating Systems scheduling and constraint optimisation
        </p>
      </div>

      <div className="panel space-y-5">
        <div>
          <label className="block text-sm font-semibold mb-2">
            Scheduling algorithm
          </label>

          <select
            className="field"
            value={mode}
            onChange={e => setMode(e.target.value)}
          >
            <option value="HYBRID">Hybrid Priority–SJF</option>
            <option value="PRIORITY">Priority Scheduling</option>
            <option value="SJF">Shortest Job First</option>
          </select>
        </div>

        {mode === "HYBRID" && (
          <>
            <div>
              <label className="text-sm font-semibold">
                Priority weight: {priority}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={priority}
                onChange={e => {
                  setPriority(Number(e.target.value));
                  setSjf(100 - Number(e.target.value));
                }}
                className="w-full mt-2"
              />
            </div>

            <div>
              <label className="text-sm font-semibold">
                SJF weight: {sjf}%
              </label>
              <div className="h-3 bg-slate-100 rounded-full overflow-hidden mt-2">
                <div
                  className="h-full bg-indigo-500"
                  style={{ width: `${sjf}%` }}
                />
              </div>
            </div>
          </>
        )}

        <div className="bg-indigo-50 rounded-lg p-4 text-sm text-indigo-900">
          <strong>Scheduling policy</strong>
          <p className="mt-1">
            OR-Tools CP-SAT evaluates feasible placements while
            enforcing faculty, room and section constraints.
          </p>
        </div>

        <button
          className="primary"
          disabled={loading}
          onClick={generate}
        >
          {loading ? "Optimising..." : "Generate timetable"}
        </button>

        {error && (
          <p className="text-red-600 text-sm">{error}</p>
        )}
      </div>

      {result && (
        <div className="panel space-y-4">
          <h3 className="font-bold text-lg">
            Optimisation result
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Metric label="Solver" value={result.solver} />
            <Metric
              label="Quality"
              value={`${result.quality_score}%`}
            />
            <Metric
              label="Scheduled"
              value={result.statistics?.scheduled ?? 0}
            />
            <Metric
              label="Unscheduled"
              value={result.unscheduled?.length ?? 0}
            />
          </div>

          <p className="text-sm">
            Version: {result.version_number}
          </p>

          <p className="text-sm">
            Validation: {result.validation?.valid ? "Passed" : "Failed"}
          </p>

          {result.unscheduled?.length > 0 && (
            <div className="bg-red-50 p-3 rounded-lg">
              <h4 className="font-semibold text-red-700">
                Unscheduled demands
              </h4>
              {result.unscheduled.map((item: any, i: number) => (
                <p key={i} className="text-sm mt-2">
                  {item.assignment_id}: {item.reason}
                </p>
              ))}
            </div>
          )}

          {result.status === "DRAFT" && (
            <button className="primary" onClick={approve}>
              Approve timetable
            </button>
          )}

          {result.status === "APPROVED" && (
            <button className="primary" onClick={publish}>
              Publish timetable
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function Metric({ label, value }: {
  label: string;
  value: string | number;
}) {
  return (
    <div className="bg-slate-50 p-3 rounded-lg">
      <p className="text-xs text-slate-500">{label}</p>
      <p className="font-bold text-xl mt-1">{value}</p>
    </div>
  );
}