import { useEffect, useState } from "react";
import api from "../api";

interface Props {
  type: string;
}

export default function Management({ type }: Props) {
  const [items, setItems] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const endpoints: Record<string, string> = {
    Departments: "academic/departments",
    Faculty: "academic/faculty",
    Students: "academic/students",
    Subjects: "academic/subjects"
  };

  const endpoint = endpoints[type];

  async function load() {
    if (!endpoint) return;

    try {
      const response = await api.get(`/${endpoint}`);
      setItems(response.data);
    } catch {
      setError("Unable to retrieve records.");
    }
  }

  useEffect(() => {
    setItems([]);
    setError("");
    setMessage("");
    load();
  }, [type]);

  async function create() {
    try {
      if (!name.trim() || !code.trim()) {
        setError("Both fields are required.");
        return;
      }

      if (type !== "Departments") {
        setError(
          "This quick-entry form is only for departments. " +
          "Use the dedicated academic API for the other entity types."
        );
        return;
      }

      await api.post(`/${endpoint}`, {
        name,
        code
      });

      setName("");
      setCode("");
      setError("");
      setMessage("Department created.");
      await load();

    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
        "Unable to create record."
      );
    }
  }

  return (
    <div className="space-y-5">
      <h2 className="text-2xl font-bold">{type}</h2>

      {type === "Departments" && (
        <div className="panel grid md:grid-cols-3 gap-3">
          <input
            className="field"
            placeholder="Department name"
            value={name}
            onChange={e => setName(e.target.value)}
          />

          <input
            className="field"
            placeholder="Department code"
            value={code}
            onChange={e => setCode(e.target.value)}
          />

          <button className="primary" onClick={create}>
            Add department
          </button>
        </div>
      )}

      {error && <p className="text-red-600">{error}</p>}
      {message && <p className="text-green-600">{message}</p>}

      <div className="panel overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>Name / ID</th>
              <th>Code / Email</th>
              <th>ID</th>
            </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.id}>
                <td>
                  {item.name || item.full_name || item.student_id}
                </td>
                <td>
                  {item.code || item.email || "-"}
                </td>
                <td className="text-xs">{item.id}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}