export interface Admin {
  id: string;
  username: string;
  email: string;
  role: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
}

export interface Faculty {
  id: string;
  faculty_id: string;
  full_name: string;
  email: string;
  department_id: string;
}

export interface Section {
  id: string;
  name: string;
  student_count: number;
  programme_id: string;
}

export interface TimetableEntry {
  id: string;
  subject: string;
  faculty: string;
  room: string;
  building: string;
  weekday: number;
  start: string;
  end: string;
  start_minute: number;
  end_minute: number;
  session_type: string;
}

export interface TimetableVersion {
  id: string;
  version_number: number;
  status: string;
  algorithm: string;
  quality_score: number;
  statistics: Record<string, unknown>;
}